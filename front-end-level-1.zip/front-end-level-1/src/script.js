let activities = JSON.parse(localStorage.getItem("activities")) || [
    { id: 1, name: "Math Assignment", description: "Complete algebra problems", completed: false },
    { id: 2, name: "Science Revision", description: "Revise physics chapter 3", completed: false }
];

let currentFilter = "all";

// Save Student Name
function saveStudentName() {
    const name = document.getElementById("studentNameInput").value;
    localStorage.setItem("studentName", name);
    displayStudentName();
}

function displayStudentName() {
    const name = localStorage.getItem("studentName");
    if (name) {
        document.getElementById("studentNameDisplay").textContent = `Student: ${name}`;
    }
}

// Add Activity
function addActivity() {
    const name = document.getElementById("activityName").value;
    const desc = document.getElementById("activityDesc").value;

    if (name === "" || desc === "") return alert("Please fill all fields");

    activities.push({
        id: Date.now(),
        name: name,
        description: desc,
        completed: false
    });

    saveData();
    renderActivities();
}

// Mark Completed
function markCompleted(id) {
    activities = activities.map(activity =>
        activity.id === id ? { ...activity, completed: true } : activity
    );
    saveData();
    renderActivities();
}

// Reset Progress
function resetProgress() {
    activities = activities.map(activity => ({
        ...activity,
        completed: false
    }));
    saveData();
    renderActivities();
}

// Filter
function filterActivities(type) {
    currentFilter = type;
    renderActivities();
}

// Save to Local Storage
function saveData() {
    localStorage.setItem("activities", JSON.stringify(activities));
}

// Render
function renderActivities() {
    const list = document.getElementById("activityList");
    list.innerHTML = "";

    let filtered = activities;

    if (currentFilter === "pending") {
        filtered = activities.filter(a => !a.completed);
    } else if (currentFilter === "completed") {
        filtered = activities.filter(a => a.completed);
    }

    filtered.forEach(activity => {
        const card = document.createElement("div");
        card.className = "activity-card";

        card.innerHTML = `
            <h3>${activity.name}</h3>
            <p>${activity.description}</p>
            <p class="status ${activity.completed ? "completed" : "pending"}">
                Status: ${activity.completed ? "Completed" : "Pending"}
            </p>
            ${!activity.completed ? `<button onclick="markCompleted(${activity.id})">Mark as Completed</button>` : ""}
        `;

        list.appendChild(card);
    });

    updateProgress();
}

// Progress
function updateProgress() {
    const total = activities.length;
    const completed = activities.filter(a => a.completed).length;

    document.getElementById("progressText").textContent =
        `${completed} out of ${total} activities completed`;

    document.getElementById("progressFill").style.width =
        total === 0 ? "0%" : (completed / total) * 100 + "%";
}

displayStudentName();
renderActivities();